sudo dstat --output ~/Collect-DCGMI/dstat-log.csv -cdnpmrt
