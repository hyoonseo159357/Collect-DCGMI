# Collect-DCGMI

Collect-DCGMI 파일 git clone 한다음 안에 pem 파일 넣어주기

sh startCLI_Oregon.sh g4dn.xlarge
